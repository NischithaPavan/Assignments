package com.Amazon.testcases;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.Amazon.Library.BaseLibrary;
import com.Amazon.Library.GenericLibrary;

import com.Amazon.Pages.TC_01_SearchProduct;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeListener;


public class TC_01_SearchProductTest extends BaseLibrary {

	TC_01_SearchProduct tc;
	
     @Test
     public void verifyAddToCart() throws InterruptedException {
    	 tc=new TC_01_SearchProduct(driver);
    	 
 	    //Search iphone 7 32gb black
    	 GenericLibrary.sendkeys(tc.clickOnSearchBox(), "iphone 7 32gb black", driver);
    	 tc.clickOnSearchBox().sendKeys(Keys.ENTER);
    	 Thread.sleep(8000);
    	 
    	// click on iphone 7 32gb black Product 
    	 GenericLibrary.click(tc.clickOnIphone7Black(), driver);
    	 //Parent Window
    	 String ParentWindow=driver.getWindowHandle();
    	 System.out.println(ParentWindow);
    	
    	 Set<String> Handle=driver.getWindowHandles();
    	 System.out.println(Handle);
    	 
    	 //Switch to Child Window
    	 for(String s:Handle) {
    		 if(s!=ParentWindow) {
    			 driver.switchTo().window(s);
    		 }
    		 
    	 }
    	 Thread.sleep(3000);
    	 //Get iphone 7 32gb black Product Price 
    	 String DisplayPrice=tc.productPrice().getText();
    	 //Display iphone 7 32gb black Product Price
		 System.out.println("Amazon, Product i Phone 7 32GB black price is->:"+DisplayPrice);
		 Thread.sleep(3000);
    	 driver.navigate().to("https://www.flipkart.com");
    	 Thread.sleep(3000);
    		 
	 try {
			GenericLibrary.click(tc.clickOnCloseIcon(), driver);
	}
		catch(Exception e) {

  	 }
	 
	 GenericLibrary.sendkeys(tc.flipkartClickOnSearch(),"iphone 7 32gb black", driver);
	 Thread.sleep(3000);
	 tc.flipkartClickOnSearch().sendKeys(Keys.ENTER);
	 Thread.sleep(3000);
	 GenericLibrary.click(tc.FlipkartClickOniPhone7(), driver);
	 Thread.sleep(3000);
	 
	 String ParentWindow1=driver.getWindowHandle();
	 System.out.println("Flipkart Parent window:->"+ParentWindow1);
	 Thread.sleep(3000);
	 
	 Set<String> handle1=driver.getWindowHandles();
	 System.out.println("Flipkart Child Window"+handle1);
	 for(String s1:handle1) {
		 if(s1!=ParentWindow1) {
			 driver.switchTo().window(s1);
		 }
		 
	 }
	 Thread.sleep(3000);
	 String DisplayFlipkartProductPrice=tc.verifyFlipkartProductprice().getText();
	 System.out.println("Flipkart, Product i Phone 7 32GB black price is->:"+DisplayFlipkartProductPrice);
	 Thread.sleep(6000);
	 int length1 = DisplayPrice.length();
	 DisplayPrice  = DisplayPrice.substring(2,length1);
	 DisplayPrice  = DisplayPrice.replace(",", "");
		
     System.out.println("Amazon=["+DisplayPrice+"]");
		double amazon1=Double.parseDouble(DisplayPrice);
		System.out.println("Amazon=["+amazon1+"]");
	 
	
	 
	
		int length = DisplayFlipkartProductPrice.length();
		DisplayFlipkartProductPrice  = DisplayFlipkartProductPrice.substring(1,length);

		DisplayFlipkartProductPrice  = DisplayFlipkartProductPrice.replace(",", "");
		System.out.println("Flipkart=["+DisplayFlipkartProductPrice+"]");
		double flipkart1=Double.parseDouble(DisplayFlipkartProductPrice);
		System.out.println("Flipkart=["+flipkart1+"]");
		

	 
	 if(amazon1>flipkart1) {
		 System.out.println("Product i Phone 7 32GB black price is greater in amazon Website");
	 }
	 else {
		 System.out.println("Product i Phone 7 32GB black price is greater in Fipkart Website");
	 }
	 
	 
	 
	 
	 
	

    	 
    	 
    	 
    	 
     }
	
}
