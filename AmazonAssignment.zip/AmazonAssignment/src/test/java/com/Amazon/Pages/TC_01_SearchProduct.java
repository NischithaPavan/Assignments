package com.Amazon.Pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TC_01_SearchProduct {
	WebDriver driver;
	public TC_01_SearchProduct(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
}
	@FindBy(xpath="//input[@id=\"twotabsearchtextbox\"]")
	private WebElement searchBox ;
    public WebElement clickOnSearchBox() {
		return searchBox;

	}
    @FindBy(xpath="//span[text()=\"Apple iPhone 7 (32GB) - Black\"]")
    private WebElement iPhone7Black;
    public WebElement clickOnIphone7Black() {
		return iPhone7Black;
    	
    }
    @FindBy(xpath="//span[starts-with(@id,'priceblock')]")
    private WebElement price;
    public WebElement productPrice() {
		return price;
    }
    
    @FindBy(xpath="//button[contains(@class,'YdH8')]")
	private WebElement clickClose;
    public WebElement clickOnCloseIcon() {
		return clickClose;
      }
    
	 @FindBy(xpath="//input[@title=\"Search for products, brands and more\"]")
	 private WebElement Flipkartsearch;
     public WebElement flipkartClickOnSearch() {
	 return Flipkartsearch;
	   }
     
     @FindBy(xpath="//div[text()=\"Apple iPhone 7 (Black, 32 GB)\"]")
	 private WebElement flipkartiPhone7;
     public WebElement  FlipkartClickOniPhone7() {
	 return flipkartiPhone7;
	  }
     
     @FindBy(xpath="//*[@id=\"container\"]/div/div[3]/div[2]/div[1]/div[2]/div[2]/div/div[3]/div[1]/div/div[1]")
	 private WebElement flipkartProductprice;
     public WebElement  verifyFlipkartProductprice(){
	 return flipkartProductprice;
	  }
		
		
		
		
		

}