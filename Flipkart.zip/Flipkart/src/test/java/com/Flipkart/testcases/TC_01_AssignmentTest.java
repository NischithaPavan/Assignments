package com.Flipkart.testcases;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.Flipkart.Library.BaseLibrary;
import com.Flipkart.Library.GenericLibrary;

import com.Flipkart.Pages.TC_01_Assignment;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeListener;


public class TC_01_AssignmentTest extends BaseLibrary {

	TC_01_Assignment tc;
	
     @Test
     public void verifyAddToCart() throws InterruptedException {
    	 tc=new TC_01_Assignment(driver);
    	 
    	 
    	 Thread.sleep(5000);
    	 try {
 			GenericLibrary.click(tc.clickOnCloseIcon(), driver);
 		}
 		catch(Exception e) {
 			
 		}
    	 //Click on Electronics
    	 GenericLibrary.mouseOver(tc.clickOnElectronics(), driver);

    	 Thread.sleep(5000);
    	 
    	 GenericLibrary.click(tc.clickOnPixel(), driver);
    	 Thread.sleep(8000);
    	 List<WebElement> ls=tc.clickOnFirstMobile();
    	 ls.get(0).click();
    	 String parentWindow=driver.getWindowHandle();
    	 System.out.println(parentWindow);
    	 Set<String> handle=driver.getWindowHandles();
    	 System.out.println(handle);
    	 for(String s:handle) {
    		 if(s!=parentWindow) {
    			 driver.switchTo().window(s);
    		 }
    	 }
    	 Thread.sleep(7000);
    	 GenericLibrary.click(tc.clickOnAddToCart(), driver);
    		Thread.sleep(3000);
    	 GenericLibrary.click(tc.clickOnPlusIcon(), driver);
    	 Thread.sleep(3000);
    	 String printAmount=tc.printTotalAmount().getText();
    	 System.out.println("Total Payable price->:"+printAmount);
    	 Thread.sleep(3000);
    	 
     }
	
}
