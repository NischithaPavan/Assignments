package com.Flipkart.Pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TC_01_Assignment {
	WebDriver driver;
	public TC_01_Assignment(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
}
	@FindBy(xpath="//button[contains(@class,'YdH8')]")
	private WebElement clickClose;
    public WebElement clickOnCloseIcon() {
		return clickClose;

	}
	@FindBy(xpath="//div[contains(@class,'sUf')]/div/ul/li[1]")
	private WebElement textElectronics;
	public WebElement clickOnElectronics() {
		return textElectronics;
	}
	@FindBy(xpath="//ul[contains(@class,'mNK')]/li[11]/a")
	private WebElement textPixel;
	public WebElement clickOnPixel() {
		return textPixel;
	}
	@FindBy(xpath="//div[contains(@class,'U0u')]")
	private List<WebElement> listOfMobiles;
	public List<WebElement> clickOnFirstMobile(){
		return listOfMobiles;
	}
	@FindBy(xpath="//button[text()='ADD TO CART']")
	private WebElement textAddToCart;
	public WebElement clickOnAddToCart() {
		return textAddToCart;
		
	}
	@FindBy(xpath="//button[text()='+']")
	private WebElement plusIcon;
	public WebElement clickOnPlusIcon() {
		return plusIcon;
		
	}
	@FindBy(xpath="//div[contains(@class,'wTWD')]/div[3]/div/span")
	private WebElement totalAmount;
	public WebElement printTotalAmount() {
		return totalAmount;
		
	}
	
	

}
