package com.Flipkart.Library;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GenericLibrary extends BaseLibrary {
	
public static String sTestDataFile=BaseLibrary.sDirPath+"\\Flipkart.xlsx";

	public static String getConfigValue(String sFile, String sKey) {
		Properties prop = new Properties();
		String sValue = null;
		try {
			InputStream ip = new FileInputStream(sFile);
			prop.load(ip);
			sValue = prop.getProperty(sKey);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sValue;
	}

	

	public static void waitForVisibility(WebElement element, WebDriver driver) {
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(element));
	}

	public static void waitForAllVisibility(WebElement eleLocation, WebDriver driver) {
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOfAllElements((List<WebElement>) eleLocation));
	}

	public static void waitForclickable(WebElement element, WebDriver driver) {
		new WebDriverWait(driver, 60).until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void click(WebElement element, WebDriver driver) {
		waitForVisibility(element, driver);
		waitForclickable(element, driver);
		element.click();

	}

	public static void sendkeys(WebElement element, String value, WebDriver driver) {
		waitForVisibility(element, driver);
		waitForclickable(element, driver);
		element.sendKeys(value);
	}

  public static String getVisibleAreaScreenshot(WebDriver driver,String ScreenshotName) {
		//Convert Webdriver instance to takeAScreenShot
		TakesScreenshot ts=(TakesScreenshot)driver;
		//Call getScreenShotAs to create image File
		File source=ts.getScreenshotAs(OutputType.FILE);
		String dest=System.getProperty("user.dir")+"//VisibleViewScreenshots//"+ScreenshotName+".png";
		File destination=new File (dest);
		
		try {
			FileUtils.copyFile(source, destination);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		return dest;
	}
	
	public static String[] toReadExcelData(String sSheet,String sTestCaseID) throws EncryptedDocumentException, InvalidFormatException, IOException {
		String[] sData=null;
		FileInputStream fis=new FileInputStream(sTestDataFile);
		//System.out.println(sTestDataFile);
		//System.out.println(sSheet);
	Workbook wb = WorkbookFactory.create(fis);
	Sheet sht=wb.getSheet(sSheet);
	int rowNum=sht.getLastRowNum();
	System.out.println(rowNum);
		for(int i=0; i<=rowNum; i++) {
			
			if(sht.getRow(i).getCell(0).toString().equals(sTestCaseID)) {
				System.out.println("Excel sheet is reading the data");
				int cellNum=sht.getRow(i).getLastCellNum();
			sData=new String[cellNum];
			
			for(int j=0; j<cellNum; j++) {
				System.out.println(j);


				sData[j]=sht.getRow(i).getCell(j).getStringCellValue();
			
				System.out.println(sData[j]);
                

				}


				break;
			}
			
		}
		
	return sData;
	}
		
  public static void mouseOver(WebElement element,WebDriver driver) {
	  Actions actions = new Actions(driver);
	  actions.moveToElement(element).build().perform();
	  click(element,driver);
}
  public static void ScrollThepage(WebDriver driver) {
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  js.executeScript("window.scrollBy(0,500)");
	  
  }
  public static void scrollUntilElementisVisible(WebElement element,WebDriver driver) {
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  js.executeScript("arguments[0].scrollIntoView();", element);
	  
  }
  
  public static void selectTest(WebElement element,WebDriver driver) {
	  
	  Select sel=new Select(element);
	  
	  
  }
}		
	
	


