package com.Flipkart.Library;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

public class BaseLibrary {

	public static WebDriver driver = null;
	public static String sDirPath = System.getProperty("user.dir");
	public static String sConfigPath = sDirPath + "\\config.properties";

	@BeforeMethod
	public void launchBrowser() throws MalformedURLException {

		System.setProperty("webdriver.chrome.driver", "browsers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get(GenericLibrary.getConfigValue(sConfigPath, "URL"));

	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
